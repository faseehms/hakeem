<!doctype html>  
<html lang=**"**ar**"** dir=**"**rtl**"**>  
  <head>  
    <meta charset=**"**UTF-8**"** />  
    <meta name=**"**viewport**"** content=**"**width=device-width, initial-scale=1.0**"** />  
    <title>**فَصيح** — **المدقق** **اللغوي** **العربي** **الخبير**</title>  
    <meta  
      name=**"**description**"**  
      content=**"منصة** **متكاملة** **للتصحيح** **الإملائي** **والنحوي،** **والضبط** **التام** **بالتشكيل،** **والإعراب** **التفصيلي،** **والبدائل** **البلاغية**.**"**  
    />  
    <link rel=**"**preconnect**"** href=**"**https://fonts.googleapis.com**"** />  
    <link rel=**"**preconnect**"** href=**"**https://fonts.gstatic.com**"** crossorigin />  
    <link  
      href=**"**https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&display=swap**"**  
      rel=**"**stylesheet**"**  
    />  
    <script src=**"**https://cdn.tailwindcss.com**"**></script>  
    <script>  
      tailwind.config = {  
        darkMode: **'**class**'**,  
        theme: {  
          extend: {  
            fontFamily: {  
              sans: [**'"**IBM Plex Sans Arabic**"'**, **'**system-ui**'**, **'**sans-serif**'**],  
              serif: [**'"**Amiri**"'**, **'**Georgia**'**, **'**serif**'**],  
            },  
          },  
        },  
      };  
    </script>  
    <style>  
      body {  
        font-family: **'**IBM Plex Sans Arabic**'**, system-ui, sans-serif;  
      }  
      .tabular-nums {  
        font-variant-numeric: tabular-nums;  
      }  
    </style>  
  </head>  
  <body class=**"**min-h-screen bg-[#f8f9fa] text-slate-900 dark:bg-[#0b111a] dark:text-slate-100 transition-colors**"**>  
    <!-- **الشريط** **العلوي** -->  
    <header class=**"**sticky top-0 z-30 border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 backdrop-blur**"**>  
      <div class=**"**mx-auto flex max-w-[1360px] items-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-8**"**>  
        <div class=**"**flex items-center gap-3**"**>  
          <span class=**"**flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-800 text-white font-serif text-xl font-bold**"**>**ف**</span>  
          <div>  
            <div class=**"**font-serif text-lg font-bold leading-none**"**>**فَصيح**</div>  
            <div class=**"**text-[11px] text-slate-500 dark:text-slate-400 mt-1**"**>**المدقق** **اللغوي** **العربي** **الخبير**</div>  
          </div>  
        </div>  
        <div class=**"**flex items-center gap-2**"**>  
          <button  
            id=**"**btn-theme**"**  
            type=**"**button**"**  
            class=**"**rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-1.5 text-xs font-medium hover:border-emerald-700 cursor-pointer**"**  
          >  
            **الوضع** **الليلي**  
          </button>  
          <button  
            id=**"**btn-open-advisor**"**  
            type=**"**button**"**  
            class=**"**rounded-lg border border-emerald-800/30 bg-emerald-50 dark:bg-emerald-950/50 px-3 py-1.5 text-xs font-semibold text-emerald-900 dark:text-emerald-300 cursor-pointer**"**  
          >  
            **اسأل** **المستشار** **اللغوي**  
          </button>  
        </div>  
      </div>  
    </header>  
  
    <!-- **المحتوى** **الرئيسي** -->  
    <main class=**"**mx-auto max-w-[1360px] px-4 py-7 sm:px-6 lg:px-8**"**>  
      <section class=**"**pb-5 mb-5 border-b border-slate-200 dark:border-slate-800 flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4**"**>  
        <div>  
          <h1 class=**"**font-serif text-3xl sm:text-4xl font-bold**"**>**فَصيح** — **المدقق** **اللغوي** **العربي** **الخبير**</h1>  
          <p class=**"**mt-2 text-sm text-slate-600 dark:text-slate-300**"**>  
            **منصة** **متكاملة** **للتصحيح** **الإملائي** **والنحوي،** **والضبط** **التام** **بالتشكيل،** **والإعراب** **التفصيلي،** **والبدائل** **البلاغية**.  
          </p>  
        </div>  
        <div class=**"**flex flex-wrap items-center gap-2**"**>  
          <div class=**"**inline-flex rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-1**"**>  
            <button data-mode=**"**comprehensive**"** class=**"**mode-btn rounded-md px-3 py-1.5 text-xs font-medium bg-emerald-800 text-white cursor-pointer**"**>  
              **تدقيق** **شامل**  
            </button>  
            <button data-mode=**"**orthography_grammar**"** class=**"**mode-btn rounded-md px-3 py-1.5 text-xs font-medium text-slate-600 dark:text-slate-300 cursor-pointer**"**>  
              **إملائي** **ونحوي** **فقط**  
            </button>  
          </div>  
          <label class=**"**inline-flex items-center gap-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2 text-xs cursor-pointer**"**>  
            <input id=**"**chk-preserve-style**"** type=**"**checkbox**"** checked class=**"**accent-emerald-800**"** />  
            <span>**الحفاظ** **على** **أسلوب** **الكاتب**</span>  
          </label>  
        </div>  
      </section>  
  
      <!-- **النماذج** + **مؤشر** **الكشف** **التلقائي** -->  
      <section class=**"**mb-5 flex flex-wrap items-center justify-between gap-3 text-xs**"**>  
        <div id=**"**samples-bar**"** class=**"**flex flex-wrap items-center gap-2**"**>  
          <span class=**"**text-slate-500 dark:text-slate-400 font-medium**"**>**نماذج** **تطبيقية**:</span>  
        </div>  
        <div id=**"**nature-indicator**"** class=**"**font-medium text-emerald-800 dark:text-emerald-400**"**>  
          **استجابة** **فورية** · Gemini Flash  
        </div>  
      </section>  
  
      <!-- **مساحة** **العمل** -->  
      <div class=**"**grid grid-cols-1 lg:grid-cols-12 gap-6**"**>  
        <!-- **المحرر** -->  
        <section class=**"**lg:col-span-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 flex flex-col**"**>  
          <div class=**"**flex items-center justify-between mb-3**"**>  
            <div class=**"**flex items-center gap-2**"**>  
              <h2 class=**"**text-sm font-bold**"**>**النص** **الأصلي**</h2>  
              <span id=**"**save-badge**"** class=**"**text-[11px] text-emerald-700 dark:text-emerald-400 opacity-0 transition-opacity**"**>**تم** **الحفظ** **تلقائياً**</span>  
            </div>  
            <button id=**"**btn-clear**"** type=**"**button**"** class=**"**text-xs text-slate-500 hover:text-rose-600 cursor-pointer**"**>**مسح** **النص**</button>  
          </div>  
          <textarea  
            id=**"**editor-input**"**  
            rows=**"**12**"**  
            placeholder=**"أدخل** **النص** **العربي** **هنا** **لتدقيقه،** **أو** **تشكيله،** **أو** **إعرابه**...**"**  
            class=**"**w-full flex-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-950 p-4 text-[15px] leading-8 outline-none focus:border-emerald-700 resize-y**"**  
          ></textarea>  
          <div id=**"**validation-msg**"** class=**"**hidden mt-2 text-xs text-rose-600 font-medium**"**></div>  
  
          <div class=**"**mt-4 flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100 dark:border-slate-800**"**>  
            <div id=**"**text-stats**"** class=**"**text-xs text-slate-500 dark:text-slate-400 tabular-nums**"**>  
              **٠** **كلمة** · **٠** **حرف** · **القراءة**: **أقل** **من** **دقيقة**  
            </div>  
            <div class=**"**flex flex-wrap items-center gap-2**"**>  
              <button id=**"**btn-tashkeel**"** type=**"**button**"** class=**"**rounded-lg border border-slate-200 dark:border-slate-700 px-3 py-2 text-xs font-semibold hover:border-emerald-700 cursor-pointer**"**>  
                **التشكيل** **الكامل**  
              </button>  
              <button id=**"**btn-irab**"** type=**"**button**"** class=**"**rounded-lg border border-slate-200 dark:border-slate-700 px-3 py-2 text-xs font-semibold hover:border-emerald-700 cursor-pointer**"**>  
                **الإعراب** **المفصل**  
              </button>  
              <button id=**"**btn-proofread**"** type=**"**button**"** class=**"**rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white px-4 py-2 text-xs font-semibold cursor-pointer**"**>  
                **تدقيق** **النص**  
              </button>  
            </div>  
          </div>  
        </section>  
  
        <!-- **النتائج** -->  
        <section class=**"**lg:col-span-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 flex flex-col**"**>  
          <div class=**"**flex flex-wrap items-center justify-between gap-2 pb-3 mb-4 border-b border-slate-100 dark:border-slate-800**"**>  
            <div class=**"**flex flex-wrap items-center gap-1**"**>  
              <button data-tab=**"**proofread**"** class=**"**tab-btn rounded-md px-3 py-1.5 text-xs font-semibold bg-emerald-800 text-white cursor-pointer**"**>**التصحيح** **والتشكيل**</button>  
              <button data-tab=**"**irab**"** class=**"**tab-btn rounded-md px-3 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 cursor-pointer**"**>**الإعراب**</button>  
              <button data-tab=**"**eloquence**"** class=**"**tab-btn rounded-md px-3 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 cursor-pointer**"**>**بدائل** **بلاغية**</button>  
            </div>  
            <div class=**"**flex items-center gap-1.5 text-xs**"**>  
              <button id=**"**btn-copy**"** type=**"**button**"** class=**"**rounded border border-slate-200 dark:border-slate-700 px-2.5 py-1 hover:border-emerald-700 cursor-pointer**"**>**نسخ**</button>  
              <button id=**"**btn-export-txt**"** type=**"**button**"** class=**"**rounded border border-slate-200 dark:border-slate-700 px-2.5 py-1 hover:border-emerald-700 cursor-pointer**"**>TXT</button>  
              <button id=**"**btn-export-doc**"** type=**"**button**"** class=**"**rounded border border-slate-200 dark:border-slate-700 px-2.5 py-1 hover:border-emerald-700 cursor-pointer**"**>Word</button>  
            </div>  
          </div>  
  
          <div id=**"**results-body**"** class=**"**flex-1 space-y-4 text-sm**"**>  
            <p class=**"**text-slate-500 dark:text-slate-400 py-10 text-center**"**>  
              **أدخل** **نصاً** **واضغط** «**تدقيق** **النص**» **أو** «**التشكيل** **الكامل**» **أو** «**الإعراب** **المفصل**» **لبدء** **التحليل**.  
            </p>  
          </div>  
        </section>  
      </div>  
  
      <!-- **تنبيهات** **الأخطاء** **الشائعة** **المحلية** -->  
      <section id=**"**patterns-section**"** class=**"**hidden mt-6 rounded-xl border border-amber-200 dark:border-amber-900/50 bg-amber-50/70 dark:bg-amber-950/20 p-5**"**>  
        <h3 class=**"**text-sm font-bold text-amber-900 dark:text-amber-300 mb-3**"**>**تنبيهات** **الأخطاء** **الشائعة** **المرصودة** **تلقائياً**</h3>  
        <div id=**"**patterns-list**"** class=**"**grid grid-cols-1 md:grid-cols-2 gap-3 text-xs**"**></div>  
      </section>  
    </main>  
  
    <!-- **نافذة** **المستشار** **اللغوي** -->  
    <aside  
      id=**"**advisor-drawer**"**  
      class=**"**hidden fixed inset-y-0 left-0 z-40 w-full max-w-md border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xl flex flex-col**"**  
    >  
      <div class=**"**flex items-center justify-between px-4 py-3 border-b border-slate-200 dark:border-slate-800**"**>  
        <div>  
          <div class=**"**font-bold text-sm**"**>**اسأل** **المستشار** **اللغوي**</div>  
          <div class=**"**text-[11px] text-slate-500 dark:text-slate-400**"**>**مرتبط** **مباشرة** **بسياق** **النص** **في** **المحرر**</div>  
        </div>  
        <button id=**"**btn-close-advisor**"** type=**"**button**"** class=**"**text-xs px-2.5 py-1 rounded border border-slate-200 dark:border-slate-700 cursor-pointer**"**>**إغلاق**</button>  
      </div>  
      <div id=**"**advisor-messages**"** class=**"**flex-1 overflow-y-auto p-4 space-y-3 text-sm**"**>  
        <div class=**"**rounded-lg bg-slate-100 dark:bg-slate-800 p-3 text-xs leading-6**"**>  
          **مرحباً** **بك**. **اسألني** **عن** **أي** **كلمة** **أو** **شاهد** **شعري** **أو** **صورة** **بلاغية** **في** **نصك** **الحالي**.  
        </div>  
      </div>  
      <form id=**"**advisor-form**"** class=**"**p-3 border-t border-slate-200 dark:border-slate-800 flex gap-2**"**>  
        <input  
          id=**"**advisor-input**"**  
          type=**"**text**"**  
          placeholder=**"مثال**: **لماذا** **نُصبت** **هذه** **الكلمة؟"**  
          class=**"**flex-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs outline-none focus:border-emerald-700**"**  
        />  
        <button type=**"**submit**"** class=**"**rounded-lg bg-emerald-800 text-white px-4 py-2 text-xs font-semibold cursor-pointer**"**>**إرسال**</button>  
      </form>  
    </aside>  
  
    <script>  
      const GEMINI_API_KEY = **'**AQ.Ab8RN6J2-03ZAmhDkN9L3BYlRYHpCMve27AJ3UvelISBc8c-GQ**'**;  
      const STORAGE_KEY = **'**faseeh_saved_editor_text**'**;  
  
      const SAMPLES = [  
        {  
          title: **'خطاب** **إداري'**,  
          text: **'السادة** **المسؤولين** **فى** **الإداره** **العامه،** **تحيه** **طيبه** **وبعد**. **نود** **إعلامكم** **بان** **الإجتماع** **السنوى** **سوف** **ينعقد** **يوم** **الثلاثاء** **القادم** **فى** **تمام** **الساعه** **العاشره** **صباحا،** **وقد** **حضر** **المدراء** **لمناقشه** **الخطه** **الجديده** **التى** **لم** **تكتمل** **بعد**.**'**,  
        },  
        {  
          title: **'فقرة** **أدبية'**,  
          text: **'ما** **اجمل** **القراءة** **حين** **يغوص** **الانسان** **في** **بطون** **الكتب** **فيكتشف** **عوالم** **جديده،** **وكم** **من** **حق** **محفوض** **يضيع** **حين** **يغفل** **الناس** **عن** **نضام** **العدالة،** **ولكن** **البعض** **يظن** **ان** **القراءه** **مضيعه** **للوقت** **وهذا** **خطئ** **شائع**.**'**,  
        },  
        {  
          title: **'شعر** **جاهلي** **وبلاغة'**,  
          text: **'قفا** **نبك** **من** **ذكرى** **حبيب** **ومنزل** **بسقط** **اللوى** **بين** **الدخول** **فحومل،** **وليل** **كموج** **البحر** **ارخى** **سدوله** **علي** **بانواع** **الهموم** **ليبتلي،** **الا** **ايها** **الليل** **الطويل** **الا** **انجلى** **بصبح** **وما** **الاصباح** **منك** **بامثل**.**'**,  
        },  
      ];  
  
      let state = {  
        mode: **'**comprehensive**'**,  
        activeTab: **'**proofread**'**,  
        result: null,  
        tashkeelText: **''**,  
        irabResult: null,  
        eloquenceResult: null,  
        advisorHistory: [],  
      };  
  
      const $ = **(**id**)** => document.getElementById**(**id**)**;  
      const escapeHtml = **(**str**)** =>  
        String**(**str || **'')**  
          .replace**(**/&/g, **'**&amp;**')**  
          .replace**(**/</g, **'**&lt;**')**  
          .replace**(**/>/g, **'**&gt;**')**  
          .replace**(**/**"**/g, **'**&quot;**')**  
          .replace**(**/**'**/g, **'**&#39;**')**;  
  
      function normalizeArabic**(**text**)** {  
        return text  
          .replace**(**/[\u064B-\u065F\u0670\u06D6-\u06ED\u0640]/g, **'')**  
          .replace**(**/[\u0671\u0622\u0623\u0625]/g, **'ا')**  
          .replace**(**/\u0649/g, **'ي')**  
          .replace**(**/\u0629/g, **'ه')**  
          .replace**(**/[^\u0600-\u06FF0-9\s]/g, **'** **')**  
          .replace**(**/\s+/g, **'** **')**  
          .trim**()**;  
      }  
  
      function detectTextNature**(**text**)** {  
        const trimmed = text.trim**()**;  
        if **(**!trimmed**)** return { containsQuranicText: false, requiresDeepThinking: false };  
        const norm = normalizeArabic**(**trimmed**)**;  
        const uthmani = /[\u0670\u0671\u06D6-\u06ED\uFD3E\uFD3F]/.test**(**trimmed**)**;  
        const quranPhrases = [**'بسم** **الله** **الرحمن** **الرحيم'**, **'الحمد** **لله** **رب** **العالمين'**, **'يا** **ايها** **الذين** **امنوا'**, **'ان** **الله** **لا** **يغير** **ما** **بقوم'**];  
        const containsQuranicText =  
          uthmani ||  
          **(**/**قال**\s+**(**?:**الله**\s+**)**?**تعالى**|**قوله**\s+**تعالى**/.test**(**trimmed**)** && /[«**"﴿**:]/.test**(**trimmed**))** ||  
          quranPhrases.some**((**p**)** => norm.includes**(**normalizeArabic**(**p**)))**;  
  
        const poetryCues = [**'قفا** **نبك'**, **'سقط** **اللوي'**, **'وليل** **كموج** **البحر'**, **'على** **قدر** **اهل** **العزم'**, **'الخيل** **والليل** **والبيداء'**];  
        const lines = trimmed.split**(**/\r?\n/**)**.map**((**l**)** => l.trim**())**.filter**(**Boolean**)**;  
        const hasTwoHemistichs = lines.some**((**l**)** => l.split**(**/\t|\s{3,}|\s*\*{2,}\s*/**)**.filter**((**p**)** => p.trim**()**.split**(**/\s+/**)**.length >= 3**)**.length === 2**)**;  
        const requiresDeepThinking = hasTwoHemistichs || poetryCues.some**((**c**)** => norm.includes**(**normalizeArabic**(**c**)))**;  
        return { containsQuranicText, requiresDeepThinking };  
      }  
  
      let saveTimer;  
      function autoSaveText**(**text**)** {  
        localStorage.setItem**(**STORAGE_KEY, text**)**;  
        const badge = $**('**save-badge**')**;  
        badge.style.opacity = **'**1**'**;  
        clearTimeout**(**saveTimer**)**;  
        saveTimer = setTimeout**(()** => { badge.style.opacity = **'**0**'**; }, 1500**)**;  
      }  
  
      function updateStatsAndNature**()** {  
        const text = $**('**editor-input**')**.value;  
        autoSaveText**(**text**)**;  
  
        const words = text.trim**()** ? text.trim**()**.split**(**/\s+/**)**.length : 0;  
        const chars = text.length;  
        const mins = Math.ceil**(**words / 180**)**;  
        $**('**text-stats**')**.textContent = `${words} **كلمة** · ${chars} **حرف** · **القراءة**: ${words === 0 ? **'٠'** : mins <= 1 ? **'أقل** **من** **دقيقة'** : mins + **'** **دقائق'**}`;  
  
        const nature = detectTextNature**(**text**)**;  
        const ind = $**('**nature-indicator**')**;  
        if **(**nature.requiresDeepThinking && nature.containsQuranicText**)** {  
          ind.textContent = **'آية** **قرآنية** **بالرسم** **العثماني** · **تحليل** **عميق** **تلقائي'**;  
        } else if **(**nature.requiresDeepThinking**)** {  
          ind.textContent = **'تحليل** **عميق** **تلقائي** · **شعر** **وبلاغة'**;  
        } else if **(**nature.containsQuranicText**)** {  
          ind.textContent = **'آية** **قرآنية** **بالرسم** **العثماني'**;  
        } else {  
          ind.textContent = **'استجابة** **فورية** · Gemini Flash**'**;  
        }  
  
        const rules = [  
          { re: /\b**(محفوض**|**نضام**|**الضلم**|**العضيم)**\b/g, title: **'الضاد** **والظاء'**, fix: **(**w**)** => w.replace**(**/**ض**/g, **'ظ')** },  
          { re: /\b**(فى**|**التى**|**الذى)**\b/g, title: **'نقطتا** **الياء'**, fix: **(**w**)** => w.replace**(**/**ى**$/, **'ي')** },  
          { re: /\b**(إجتماع**|**إستقبال**|**إنتهاء)**\b/g, title: **'همزة** **الوصل'**, fix: **(**w**)** => w.replace**(**/^**إ**/, **'ا')** },  
        ];  
        const found = [];  
        rules.forEach**((**r**)** => {  
          const matches = text.match**(**r.re**)**;  
          if **(**matches**)** [...new Set**(**matches**)**].forEach**((**m**)** => found.push**(**{ title: r.title, wrong: m, right: r.fix**(**m**)** }**))**;  
        }**)**;  
        if **(**found.length**)** {  
          $**('**patterns-section**')**.classList.remove**('**hidden**')**;  
          $**('**patterns-list**')**.innerHTML = found  
            .map**(**  
              **(**f**)** => `<div class=**"**rounded-lg bg-white dark:bg-slate-900 border border-amber-200 dark:border-amber-800 p-3 flex items-center justify-between**"**>  
                <span><strong>${escapeHtml**(**f.title**)**}:</strong> <span class=**"**line-through text-rose-600**"**>${escapeHtml**(**f.wrong**)**}</span> ← <span class=**"**text-emerald-700 font-bold**"**>${escapeHtml**(**f.right**)**}</span></span>  
              </div>`,  
            **)**  
            .join**('')**;  
        } else {  
          $**('**patterns-section**')**.classList.add**('**hidden**')**;  
        }  
      }  
  
      async function callGemini**(**prompt, expectJson = true**)** {  
        const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent**(**GEMINI_API_KEY**)**}`;  
        const body = {  
          contents: [{ parts: [{ text: prompt }] }],  
          generationConfig: expectJson ? { responseMimeType: **'**application/json**'** } : {},  
        };  
        const res = await fetch**(**url, {  
          method: **'**POST**'**,  
          headers: { **'**Content-Type**'**: **'**application/json**'** },  
          body: JSON.stringify**(**body**)**,  
        }**)**;  
        if **(**!res.ok**)** throw new Error**('تعذر** **الاتصال** **بمحرك** **الذكاء** **الاصطناعي')**;  
        const data = await res.json**()**;  
        const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text || **''**;  
        return expectJson ? JSON.parse**(**rawText**)** : rawText;  
      }  
  
      function renderResults**()** {  
        const container = $**('**results-body**')**;  
        if **(**state.activeTab === **'**irab**')** {  
          if **(**!state.irabResult**)** {  
            container.innerHTML = **'**<p class=**"**text-slate-500 text-center py-8**"**>**اضغط** «**الإعراب** **المفصل**» **لتحليل** **الجملة**.</p>**'**;  
            return;  
          }  
          const bHtml = **(**state.irabResult.breakdown || []**)**  
            .map**((**b**)** => `<div class=**"**rounded-lg border border-slate-200 dark:border-slate-700 p-3**"**><strong>${escapeHtml**(**b.token**)**}</strong> **(**${escapeHtml**(**b.role**)**}**)**: ${escapeHtml**(**b.irab**)**}</div>`**)**  
            .join**('')**;  
          container.innerHTML = `  
            <div class=**"**rounded-lg bg-emerald-50 dark:bg-emerald-950/40 p-4 border border-emerald-200 dark:border-emerald-800**"**>  
              <div class=**"**font-bold text-emerald-900 dark:text-emerald-300**"**>${escapeHtml**(**state.irabResult.grammaticalRole || **'التحليل** **الإعرابي** **الشامل')**}</div>  
              <p class=**"**mt-1 leading-7**"**>${escapeHtml**(**state.irabResult.detailedIrab || **'')**}</p>  
            </div>  
            <div class=**"**space-y-2**"**>${bHtml}</div>`;  
          return;  
        }  
  
        if **(**state.activeTab === **'**eloquence**')** {  
          if **(**!state.eloquenceResult**)** {  
            container.innerHTML = `<div class=**"**text-center py-8**"**><button onclick=**"**fetchEloquence**()"** class=**"**rounded-lg bg-emerald-800 text-white px-4 py-2 text-xs font-semibold cursor-pointer**"**>**استخراج** **البدائل** **البلاغية**</button></div>`;  
            return;  
          }  
          container.innerHTML = **(**state.eloquenceResult.suggestions || []**)**  
            .map**(**  
              **(**s**)** => `<div class=**"**rounded-lg border border-slate-200 dark:border-slate-700 p-3 space-y-2**"**>  
                <div class=**"**font-bold text-rose-700 dark:text-rose-400**"**>${escapeHtml**(**s.originalPhrase**)**}</div>  
                <p class=**"**text-xs text-slate-600 dark:text-slate-300**"**>${escapeHtml**(**s.rhetoricalReason**)**}</p>  
                <div class=**"**flex flex-wrap gap-2**"**>${**(**s.alternatives || []**)**.map**((**a**)** => `<span class=**"**rounded bg-emerald-50 dark:bg-emerald-900/40 px-2.5 py-1 text-xs font-semibold**"**>${escapeHtml**(**a.phrase**)**}</span>`**)**.join**('')**}</div>  
              </div>`,  
            **)**  
            .join**('')**;  
          return;  
        }  
  
        const r = state.result;  
        if **(**!r && !state.tashkeelText**)** {  
          container.innerHTML = **'**<p class=**"**text-slate-500 text-center py-10**"**>**أدخل** **نصاً** **واضغط** «**تدقيق** **النص**» **لبدء** **التحليل**.</p>**'**;  
          return;  
        }  
  
        const quranBanner = r?.containsQuranicText  
          ? `<div class=**"**rounded-lg border border-emerald-300 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/50 p-3 text-xs font-medium text-emerald-900 dark:text-emerald-200**"**>**آية** **قرآنية** **بالرسم** **العثماني**: **التزم** **المحرك** **بحفظ** **الرسم** **العثماني** **والقراءات** **المتواترة** **دون** **تعديل**.</div>`  
          : **''**;  
        const textOutput = state.tashkeelText || r?.correctedText || **''**;  
        const correctionsHtml = **(**r?.corrections || []**)**  
          .map**(**  
            **(**c**)** => `<div class=**"**rounded-lg border border-slate-200 dark:border-slate-700 p-3 text-xs space-y-1**"**>  
              <div><span class=**"**line-through text-rose-600**"**>${escapeHtml**(**c.original**)**}</span> ← <span class=**"**text-emerald-700 font-bold**"**>${escapeHtml**(**c.corrected**)**}</span></div>  
              <div class=**"**font-semibold**"**>${escapeHtml**(**c.ruleTitle**)**}</div>  
              <p class=**"**text-slate-600 dark:text-slate-300**"**>${escapeHtml**(**c.explanation**)**}</p>  
            </div>`,  
          **)**  
          .join**('')**;  
        const insightsHtml = **(**r?.rhetoricalInsights || []**)**  
          .map**(**  
            **(**i**)** => `<div class=**"**rounded-lg border border-amber-200 dark:border-amber-800 bg-amber-50/50 dark:bg-amber-950/20 p-3 text-xs space-y-1**"**>  
              <div class=**"**font-bold text-amber-900 dark:text-amber-300**"**>${escapeHtml**(**i.phenomenon**)**}: «${escapeHtml**(**i.excerpt**)**}»</div>  
              <p><strong>**الوجه** **البلاغي**:</strong> ${escapeHtml**(**i.rhetoricalFacet**)**}</p>  
              <p><strong>**التأويل** **النحوي** **(سيبويه** **وابن** **جني)**:</strong> ${escapeHtml**(**i.grammaticalInterpretations**)**}</p>  
            </div>`,  
          **)**  
          .join**('')**;  
  
        container.innerHTML = `  
          ${quranBanner}  
          <div class=**"**rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 p-4 font-serif text-lg leading-9 whitespace-pre-wrap**"**>${escapeHtml**(**textOutput**)**}</div>  
          ${r?.summary ? `<p class=**"**text-xs text-slate-600 dark:text-slate-300**"**>${escapeHtml**(**r.summary**)**}</p>` : **''**}  
          ${insightsHtml ? `<div class=**"**space-y-2**"**><h4 class=**"**text-xs font-bold**"**>**التأويل** **النحوي** **والوجه** **البلاغي** **(منهج** **سيبويه** **وابن** **جني)**</h4>${insightsHtml}</div>` : **''**}  
          ${correctionsHtml ? `<div class=**"**space-y-2**"**><h4 class=**"**text-xs font-bold**"**>**التصحيحات** **المقترحة** **(**${r.corrections.length}**)**</h4>${correctionsHtml}</div>` : **''**}`;  
      }  
  
      async function runProofread**()** {  
        const text = $**('**editor-input**')**.value.trim**()**;  
        if **(**!text**)** {  
          $**('**validation-msg**')**.textContent = **'يرجى** **إدخال** **نص** **عربي** **قبل** **التدقيق**.**'**;  
          $**('**validation-msg**')**.classList.remove**('**hidden**')**;  
          return;  
        }  
        $**('**validation-msg**')**.classList.add**('**hidden**')**;  
        state.activeTab = **'**proofread**'**;  
        state.tashkeelText = **''**;  
        state.result = { correctedText: **''**, summary: **'جارٍ** **التدقيق** **اللغوي** **الخبير**...**'**, corrections: [], rhetoricalInsights: [] };  
        renderResults**()**;  
  
        const nature = detectTextNature**(**text**)**;  
        const preserveStyle = $**('**chk-preserve-style**')**.checked;  
        const prompt = `**أنت** **مدقق** **لغوي** **عربي** **خبير** **(فَصيح)**. **قم** **بتدقيق** **النص** **التالي** **بدقة** **فائقة**:  
**النص**: **"""**${text}**"""**  
**نوع** **التدقيق**: ${state.mode === **'**comprehensive**'** ? **'تدقيق** **شامل** **(إملائي** **ونحوي** **وصرفي** **وعلامات** **ترقيم** **وبلاغة)'** : **'تصحيح** **الأخطاء** **الإملائية** **والنحوية** **فقط'**}  
**الحفاظ** **على** **أسلوب** **الكاتب**: ${preserveStyle ? **'نعم'** : **'لا'**}  
${nature.containsQuranicText ? **'تنبيه**: **النص** **يتضمن** **آية** **قرآنية،** **التزم** **بالرسم** **العثماني** **والقراءة** **المتواترة** **دون** **أي** **تعديل**.**'** : **''**}  
${nature.requiresDeepThinking ? **'تنبيه**: **النص** **أدبي** **أو** **شعري،** **قدم** **تحليلاً** **بلاغياً** **وتأويلاً** **نحوياً** **معمقاً** **على** **منهج** **سيبويه** **وابن** **جني**.**'** : **''**}  
  
**أعد** **النتيجة** **بصيغة** JSON **حصراً** **وفق** **البنية** **التالية**:  
{  
  **"**containsQuranicText**"**: boolean,  
  **"**correctedText**"**: **"النص** **المصحح** **والمضبوط** **بالكامل"**,  
  **"**summary**"**: **"ملخص** **موجز** **لأبرز** **ما** **تم** **تصحيحه"**,  
  **"**corrections**"**: [  
    { **"**original**"**: **"الكلمة** **الخطأ"**, **"**corrected**"**: **"الصواب"**, **"**ruleTitle**"**: **"اسم** **القاعدة"**, **"**explanation**"**: **"تعليل** **التصحيح"** }  
  ],  
  **"**rhetoricalInsights**"**: [  
    { **"**phenomenon**"**: **"الظاهرة** **البلاغية** **أو** **النحوية"**, **"**excerpt**"**: **"الشاهد** **من** **النص"**, **"**rhetoricalFacet**"**: **"الوجه** **البلاغي"**, **"**grammaticalInterpretations**"**: **"التأويل** **النحوي"** }  
  ]  
}`;  
  
        try {  
          state.result = await callGemini**(**prompt, true**)**;  
          renderResults**()**;  
        } catch **(**err**)** {  
          state.result = { correctedText: text, summary: **'حدث** **خطأ** **أثناء** **الاتصال**: **'** + err.message, corrections: [], rhetoricalInsights: [] };  
          renderResults**()**;  
        }  
      }  
  
      async function runTashkeel**()** {  
        const text = $**('**editor-input**')**.value.trim**()**;  
        if **(**!text**)** return;  
        state.activeTab = **'**proofread**'**;  
        state.tashkeelText = **'جارٍ** **الضبط** **التام** **بالشكل**...**'**;  
        renderResults**()**;  
  
        const prompt = `**اضبط** **النص** **العربي** **التالي** **بالشكل** **الكامل** **والدقيق** **(تشكيل** **أواخر** **الكلمات** **وبنيتها** **الصرفية** **بدقة** **نحوية** **تامة** **دون** **تغيير** **أي** **كلمة)**:  
**"""**${text}**"""**  
**أعد** **النتيجة** **بصيغة** JSON **حصراً**: { **"**vocalizedText**"**: **"النص** **المشكول** **بالكامل"** }`;  
  
        try {  
          const data = await callGemini**(**prompt, true**)**;  
          state.tashkeelText = data.vocalizedText || text;  
          renderResults**()**;  
        } catch **(**err**)** {  
          state.tashkeelText = **'حدث** **خطأ** **أثناء** **التشكيل**: **'** + err.message;  
          renderResults**()**;  
        }  
      }  
  
      async function runIrab**()** {  
        const text = $**('**editor-input**')**.value.trim**()**;  
        if **(**!text**)** return;  
        state.activeTab = **'**irab**'**;  
        state.irabResult = { grammaticalRole: **'جارٍ** **الإعراب** **المفصل**...**'**, detailedIrab: **'يرجى** **الانتظار** **لحظات**...**'**, breakdown: [] };  
        renderResults**()**;  
  
        const prompt = `**أعرب** **النص** **العربي** **التالي** **إعراباً** **نحوياً** **تفصيلياً** **دقيقاً** **(إعراب** **الجمل** **وإعراب** **المفردات)**:  
**"""**${text}**"""**  
**أعد** **النتيجة** **بصيغة** JSON **حصراً**:  
{  
  **"**grammaticalRole**"**: **"ملخص** **المحل** **الإعرابي** **للجمل"**,  
  **"**detailedIrab**"**: **"شرح** **إعرابي** **وافٍ"**,  
  **"**breakdown**"**: [  
    { **"**token**"**: **"الكلمة"**, **"**role**"**: **"الموقع** **الإعرابي"**, **"**irab**"**: **"الإعراب** **الكامل** **مع** **العلامة"** }  
  ]  
}`;  
  
        try {  
          state.irabResult = await callGemini**(**prompt, true**)**;  
          renderResults**()**;  
        } catch **(**err**)** {  
          state.irabResult = { grammaticalRole: **'خطأ'**, detailedIrab: err.message, breakdown: [] };  
          renderResults**()**;  
        }  
      }  
  
      async function fetchEloquence**()** {  
        const text = state.result?.correctedText || $**('**editor-input**')**.value.trim**()**;  
        if **(**!text**)** return;  
        $**('**results-body**')**.innerHTML = **'**<p class=**"**text-slate-500 text-center py-8**"**>**جارٍ** **استخراج** **البدائل** **البلاغية** **والأسلوبية**...</p>**'**;  
  
        const prompt = `**اقترح** **بدائل** **بلاغية** **وأسلوبية** **أرقى** **وأفصح** **للعبارات** **في** **النص** **التالي**:  
**"""**${text}**"""**  
**أعد** **النتيجة** **بصيغة** JSON **حصراً**:  
{  
  **"**suggestions**"**: [  
    {  
      **"**originalPhrase**"**: **"العبارة** **الأصلية"**,  
      **"**rhetoricalReason**"**: **"سبب** **التحسين** **البلاغي"**,  
      **"**alternatives**"**: [{ **"**phrase**"**: **"البديل** **المقترح"** }]  
    }  
  ]  
}`;  
  
        try {  
          state.eloquenceResult = await callGemini**(**prompt, true**)**;  
          renderResults**()**;  
        } catch **(**err**)** {  
          $**('**results-body**')**.innerHTML = `<p class=**"**text-rose-600 text-center py-8**"**>${escapeHtml**(**err.message**)**}</p>`;  
        }  
      }  
  
      // **تهيئة** **الأزرار** **والنماذج**  
      SAMPLES.forEach**((**s**)** => {  
        const btn = document.createElement**('**button**')**;  
        btn.type = **'**button**'**;  
        btn.textContent = s.title;  
        btn.className = **'**rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-1.5 font-medium hover:border-emerald-700 cursor-pointer**'**;  
        btn.onclick = **()** => {  
          $**('**editor-input**')**.value = s.text;  
          updateStatsAndNature**()**;  
        };  
        $**('**samples-bar**')**.appendChild**(**btn**)**;  
      }**)**;  
  
      // **استرجاع** **النص** **المحفوظ** **تلقائياً** **عند** **فتح** **الصفحة**  
      const savedText = localStorage.getItem**(**STORAGE_KEY**)**;  
      if **(**savedText**)** {  
        $**('**editor-input**')**.value = savedText;  
        updateStatsAndNature**()**;  
      }  
  
      $**('**editor-input**')**.addEventListener**('**input**'**, updateStatsAndNature**)**;  
      $**('**btn-clear**')**.onclick = **()** => { $**('**editor-input**')**.value = **''**; updateStatsAndNature**()**; };  
      $**('**btn-proofread**')**.onclick = runProofread;  
      $**('**btn-tashkeel**')**.onclick = runTashkeel;  
      $**('**btn-irab**')**.onclick = runIrab;  
      $**('**btn-theme**')**.onclick = **()** => document.documentElement.classList.toggle**('**dark**')**;  
      $**('**btn-open-advisor**')**.onclick = **()** => $**('**advisor-drawer**')**.classList.remove**('**hidden**')**;  
      $**('**btn-close-advisor**')**.onclick = **()** => $**('**advisor-drawer**')**.classList.add**('**hidden**')**;  
  
      document.querySelectorAll**('**.mode-btn**')**.forEach**((**btn**)** => {  
        btn.onclick = **()** => {  
          state.mode = btn.dataset.mode;  
          document.querySelectorAll**('**.mode-btn**')**.forEach**((**b**)** => {  
            b.className = b === btn  
              ? **'**mode-btn rounded-md px-3 py-1.5 text-xs font-medium bg-emerald-800 text-white cursor-pointer**'**  
              : **'**mode-btn rounded-md px-3 py-1.5 text-xs font-medium text-slate-600 dark:text-slate-300 cursor-pointer**'**;  
          }**)**;  
        };  
      }**)**;  
  
      document.querySelectorAll**('**.tab-btn**')**.forEach**((**btn**)** => {  
        btn.onclick = **()** => {  
          state.activeTab = btn.dataset.tab;  
          document.querySelectorAll**('**.tab-btn**')**.forEach**((**b**)** => {  
            b.className = b === btn  
              ? **'**tab-btn rounded-md px-3 py-1.5 text-xs font-semibold bg-emerald-800 text-white cursor-pointer**'**  
              : **'**tab-btn rounded-md px-3 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 cursor-pointer**'**;  
          }**)**;  
          renderResults**()**;  
        };  
      }**)**;  
  
      $**('**btn-copy**')**.onclick = **()** => navigator.clipboard.writeText**(**state.tashkeelText || state.result?.correctedText || $**('**editor-input**')**.value**)**;  
      $**('**btn-export-txt**')**.onclick = **()** => {  
        const blob = new Blob**(**[state.tashkeelText || state.result?.correctedText || $**('**editor-input**')**.value], { type: **'**text/plain;charset=utf-8**'** }**)**;  
        const a = document.createElement**('**a**')**;  
        a.href = URL.createObjectURL**(**blob**)**;  
        a.download = **'**faseeh-output.txt**'**;  
        a.click**()**;  
      };  
      $**('**btn-export-doc**')**.onclick = **()** => {  
        const txt = escapeHtml**(**state.tashkeelText || state.result?.correctedText || $**('**editor-input**')**.value**)**.replace**(**/\n/g, **'**<br>**')**;  
        const blob = new Blob**(**[`<html dir=**"**rtl**"** lang=**"**ar**"**><meta charset=**"**utf-8**"**><body><p style=**"**font-family:Arial;font-size:16px;line-height:1.9**"**>${txt}</p></body></html>`], { type: **'**application/msword**'** }**)**;  
        const a = document.createElement**('**a**')**;  
        a.href = URL.createObjectURL**(**blob**)**;  
        a.download = **'**faseeh-output.doc**'**;  
        a.click**()**;  
      };  
  
      $**('**advisor-form**')**.onsubmit = async **(**e**)** => {  
        e.preventDefault**()**;  
        const q = $**('**advisor-input**')**.value.trim**()**;  
        if **(**!q**)** return;  
        $**('**advisor-input**')**.value = **''**;  
        const box = $**('**advisor-messages**')**;  
        box.innerHTML += `<div class=**"**rounded-lg bg-emerald-800 text-white p-3 text-xs self-end**"**>${escapeHtml**(**q**)**}</div>`;  
        const replyEl = document.createElement**('**div**')**;  
        replyEl.className = **'**rounded-lg bg-slate-100 dark:bg-slate-800 p-3 text-xs leading-6 whitespace-pre-wrap**'**;  
        replyEl.textContent = **'جارٍ** **التحليل**...**'**;  
        box.appendChild**(**replyEl**)**;  
  
        const prompt = `**أنت** **مستشار** **لغوي** **عربي** **خبير**. **أجب** **باختصار** **ودقة** **علمية** **عن** **سؤال** **المستخدم** **بناءً** **على** **النص** **الموجود** **في** **المحرر**.  
**النص** **في** **المحرر**: **"""**${$**('**editor-input**')**.value}**"""**  
**سؤال** **المستخدم**: ${q}`;  
  
        try {  
          const reply = await callGemini**(**prompt, false**)**;  
          replyEl.textContent = reply;  
          state.advisorHistory.push**(**{ role: **'**user**'**, text: q }, { role: **'**model**'**, text: reply }**)**;  
        } catch **(**err**)** {  
          replyEl.textContent = **'تعذر** **الحصول** **على** **إجابة**: **'** + err.message;  
        }  
      };  
    </script>  
  </body>  
</html>  
